﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NbaProje.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace NbaProje.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Atlanta()
        {
            List<Players> plist = new List<Players>();
            using (var client = new HttpClient())
            {

                var responsetalk = client.GetAsync("https://localhost:44375/api/Home/Players");
                var result = responsetalk.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();
                    var player = readTask.Result;
                    plist = JsonConvert.DeserializeObject<List<Players>>(player);

                }
            }
            return View(plist);
           
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult Oyuncu()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
