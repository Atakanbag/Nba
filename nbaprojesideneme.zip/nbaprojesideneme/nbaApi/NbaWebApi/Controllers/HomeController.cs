﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NbaBusiness.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NbaWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    public class HomeController : ControllerBase
    {
        
        private INbaService ndb;
        public HomeController(INbaService _ndb)
        {
            ndb = _ndb;
        }
        
        [HttpGet("Players")]
        public IActionResult GetAllPlayers()
        {
            
            var player = ndb.GetAllPlayers();
            return Ok(player);
        }
    }
}
