﻿using NbaBusiness.Abstract;
using NbaDataAccess.Abstract;
using NbaEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NbaBusiness.Concrete
{
    public class NbaService : INbaService
    {
        private INbaRepository rep;
        public NbaService(INbaRepository _rep)
        {
            rep = _rep;
        }
        public Players CreatePlayers(Players player)
        {
            return rep.CreatePlayers(player);
        }

        

        public void DeletePlayers(int id)
        {
            rep.DeletePlayers(id);
        }

       

        public List<Players> GetAllPlayers()
        {
           return rep.GetAllPlayers();
        }

        

        public Players GetPlayerByID(int id)
        {
            return rep.GetPlayerByID(id);
        }

       

        public Players UpdatePlayers(Players player)
        {
            return rep.UpdatePlayers(player);
        }

        
    }
}
