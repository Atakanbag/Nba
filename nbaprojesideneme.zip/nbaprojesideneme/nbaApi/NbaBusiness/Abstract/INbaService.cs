﻿using NbaEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NbaBusiness.Abstract
{
   public interface INbaService
    {
        List<Players> GetAllPlayers();
        Players GetPlayerByID(int id);
        Players CreatePlayers(Players player);
        Players UpdatePlayers(Players player);

        void DeletePlayers(int id);
        
    }
}
