﻿using CsvHelper.Configuration.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NbaEntities
{
   public class Players
    {
        [DisplayName("ID")]
        public int PlayersID { get; set; }
        [DisplayName("Jersey Number")]
        public int PlayerJerseyNo { get; set; }
        [DisplayName("Name")]
        public string PlayerName { get; set; }
        [DisplayName("Surname")]
        public string PlayerSurname { get; set; }
        public string Position { get; set; }
        public decimal Height { get; set; }
        public decimal Weight { get; set; }
        [DisplayName("Team Name")]
        public string TeamName { get; set; }
        [DisplayName("Team City")]
        public string TeamCity { get; set; }
        [DisplayName("Team Arena")]
        public string TeamArena { get; set; }
        [DisplayName("Championships")]
        public int ChampPoint { get; set; }
        public decimal Points { get; set; }
        public decimal Rebounds { get; set; }
        public decimal Assists { get; set; }
        [DisplayName("%FG")]
        public decimal FieldGoalPercentage { get; set; }
        [DisplayName("%3PFG")]
        public decimal TPFieldGoalPercentage { get; set; }
        [DisplayName("%FT")]
        public decimal FreeThrowPercentage { get; set; }
        public decimal Turnovers { get; set; }
        public decimal Blocks { get; set; }
        [DisplayName("Games Played")]
        public int GamesPlayed { get; set; }




    }
}
