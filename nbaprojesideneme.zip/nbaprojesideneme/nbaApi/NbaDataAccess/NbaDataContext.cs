﻿using Microsoft.EntityFrameworkCore;
using NbaEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NbaDataAccess
{
   class NbaDataContext:DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseSqlServer("Server=ATAKAN\\MSSQLSERVER01; Database=NbaDB; Trusted_Connection=true;");
        }
        public DbSet<Players> players { get; set; }
        

    }
}
