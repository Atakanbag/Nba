﻿using NbaDataAccess.Abstract;
using NbaEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NbaDataAccess.Concrete
{
    public class NbaRepository : INbaRepository
    {
        public Players CreatePlayers(Players player)
        {
            using(var db=new NbaDataContext())
            {
                db.players.Add(player);
                db.SaveChanges();
                return player;
            }
        }

        

        public void DeletePlayers(int id)
        {
            using (var db = new NbaDataContext())
            {
                var deleted = GetPlayerByID(id);
                db.players.Remove(deleted);
                db.SaveChanges();
            }
        }

       

        public List<Players> GetAllPlayers()
        {
            using (var db = new NbaDataContext())
            {
                return db.players.ToList();
            }
        }

       

        public Players GetPlayerByID(int id)
        {
            using (var db = new NbaDataContext())
            {
                return db.players.FirstOrDefault(x => x.PlayersID == id);
            }
        }

       

        public Players UpdatePlayers(Players player)
        {
            using (var db = new NbaDataContext())
            {
                db.players.Update(player);
                db.SaveChanges();
                return player;
            }
        }

       
    }
}
