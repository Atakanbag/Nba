﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace NbaDataAccess.Migrations
{
    public partial class eklenbadb : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "players",
                columns: table => new
                {
                    PlayersID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PlayerJerseyNo = table.Column<int>(type: "int", nullable: false),
                    PlayerName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PlayerSurname = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Position = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Height = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Weight = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    TeamName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TeamCity = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TeamArena = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ChampPoint = table.Column<int>(type: "int", nullable: false),
                    Points = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Rebounds = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Assists = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    FieldGoalPercentage = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    TPFieldGoalPercentage = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    FreeThrowPercentage = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Turnovers = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Blocks = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    GamesPlayed = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_players", x => x.PlayersID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "players");
        }
    }
}
